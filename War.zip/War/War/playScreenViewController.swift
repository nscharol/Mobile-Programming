//
//  playScreenViewController.swift
//  War
//
//  Created by COSC2125 on 2/13/18.
//  Copyright © 2018 COSC2125. All rights reserved.
//

import UIKit



class playScreenViewController: UIViewController {

    var warGame = WarDeck(cardCount: 52)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBOutlet weak var imgBluesTableCard: UIImage!
    @IBOutlet weak var imgRedsTableCard: UIImage!
    
    
    @IBAction func dealButton(_ sender: UIButton) {
        
        imgBluesTableCard = warGame.getCardImage(card: warGame.getTopCard(player: 1))
        imgRedsTableCard = warGame.getCardImage(card: warGame.getTopCard(player: 2))
        
        
    }
    
    
        
    
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
