//
//  WarDeck.swift
//  War
//
//  Created by COSC2125 on 2/13/18.
//  Copyright © 2018 COSC2125. All rights reserved.
//
import Foundation
import GameplayKit

class WarDeck
{
    var playerOneDeckArray : [Int] = []
    var playerTwoDeckArray : [Int] = []
    
    
    init(cardDeck : [Int]) {
        
        var cards : [Int] = cardDeck
        while !cardDeck.isEmpty {
            playerOneDeckArray[0] = cards.removeFirst()
            playerTwoDeckArray[0] = cards.removeFirst()
        }
        
        
    }
    
    func getCard(player : Int) -> Int {
        assert(player == 1 || player == 2)
        if (player == 1)
        {
        return self.playerOneDeckArray.first!
        }
        else
        {
            return self.playerTwoDeckArray.first!
        }
    }
    
    func playRound() -> Void {
        let playerOnesCard : Int = self.playerOneDeckArray.removeFirst()
        let playerTwosCard : Int = self.playerTwoDeckArray.removeFirst()
        
        if (playerOnesCard > playerTwosCard)
        {
            self.playerOneDeckArray.append(playerOnesCard)
            self.playerOneDeckArray.append(playerTwosCard)
        }
        else if (playerTwosCard > playerOnesCard)
        {
            self.playerTwoDeckArray.append(playerTwosCard)
            self.playerTwoDeckArray.append(playerOnesCard)
        }
        else
        {
            self.playerOneDeckArray.append(playerOnesCard)
            self.playerTwoDeckArray.append(playerTwosCard)
        }
        
        self.playerOneDeckArray = shuffle(player: 1, deckArray: self.playerOneDeckArray)
        self.playerTwoDeckArray = shuffle(player: 2, deckArray: self.playerTwoDeckArray)
        
    }
    
    func shuffle(player : Int, deckArray : [Int]) -> [Int] {
        assert(player == 1 || player == 2)
        assert(deckArray.count > 0)
        
        let shuffledDeck = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: deckArray) as? [Int]
        
        
        if player == 1 {
            self.playerOneDeckArray = shuffledDeck!
        }
        else
        {
            self.playerTwoDeckArray = shuffledDeck!
        }
        
        return shuffledDeck!
    }
    
    func isGameOver(deckArray : [Int], secondDeckArray : [Int]) -> Bool {
        if deckArray.count==0 || secondDeckArray.count==0{
            return true
        }
        else
        {
            return false
        }
    
    }
    
    func getWinner(playerOneArray : [Int], playerTwoArray : [Int]) -> Int? {
        assert(isGameOver(deckArray: self.playerOneDeckArray, secondDeckArray: self.playerTwoDeckArray))
        
        if playerOneArray.count == 0 {
            return 1
        }
        else if playerTwoArray.count == 0
        {
            return 2
        }
        else
        {
            return nil
        }
        
    }
        
        
  
    }
    
    
    

    
    

