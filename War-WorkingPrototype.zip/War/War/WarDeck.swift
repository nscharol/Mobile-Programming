//
//  WarDeck.swift
//  War
//
//  Created by COSC2125 on 2/13/18.
//  Copyright © 2018 COSC2125. All rights reserved.
//
import Foundation
import GameplayKit
import UIKit
import AVFoundation


    let twosCardArray : [Int] = [1, 14, 27, 40]
    let threesCardArray : [Int] = [2, 15, 28, 41]
    let foursCardArray : [Int] = [3, 16, 29, 42]
    let fivesCardArray : [Int] = [4, 17, 30, 43]
    let sixsCardArray : [Int] = [5, 18, 31, 44]
    let sevensCardArray : [Int] = [6, 19, 32, 45]
    let eightsCardArray : [Int] = [7, 20, 33, 46]
    let ninesCardArray : [Int] = [8, 21, 34, 47]
    let tensCardArray : [Int] = [9, 22, 35, 48]
    let jacksCardArray : [Int] = [10, 23, 36, 49]
    let queensCardArray : [Int] = [11, 24, 37, 50]
    let kingsCardArray : [Int] = [12, 25, 38, 51]
    let acesCardArray : [Int] = [13, 26, 39, 52]

    let spadesCardArray : [Int] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
    let heartsCardArray : [Int] = [14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26]
    let clubsCardArray : [Int] = [27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39]
    let diamondsCardArray : [Int] = [40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52]
    let totalCardsArray : [[Int]] = [twosCardArray, threesCardArray, foursCardArray, fivesCardArray, sixsCardArray, sevensCardArray, eightsCardArray, ninesCardArray, tensCardArray, jacksCardArray, queensCardArray, kingsCardArray, acesCardArray]

    var playersPot : [Int] = []

var isWar : Bool? = nil


class WarDeck
{
    
    
    
    
    
    
    var playerOneDeckArray : [Int] = []
    var playerTwoDeckArray : [Int] = []
    
    
    init() {
        
        
        
        var cardDeck : [Int] = [] //This will be the deck our players are dealt from
        
        for array in totalCardsArray {
            for card in array
            {
                cardDeck.append(card)
                print("card added to deck : \(card)")
            }
        }
        print("Success: all cards added to deck from which player's decks are dealt...")
        
        var cards : [Int] = cardDeck
        
        while !cards.isEmpty {
            self.playerOneDeckArray.append(cards.removeFirst())
            print("\(self.playerOneDeckArray.last!) added to player ones deck")
            self.playerTwoDeckArray.append(cards.removeFirst())
            print("\(self.playerTwoDeckArray.last!) added to player twos deck")
        }
        print("Success: all player decks have been dealt")
        
        shuffle(player: 1, deckArray: self.playerOneDeckArray)
        print("Success: player one's deck has been shuffled")
        shuffle(player: 2, deckArray: self.playerTwoDeckArray)
        print("Success: player two's deck has been shuffled")
    }
    
    func getTopCard(player : Int) -> Int {
        assert(player == 1 || player == 2)
        
        if (player == 1)
        {
        return self.playerOneDeckArray.first!
        }
        else
        {
            return self.playerTwoDeckArray.first!
        }
    }
    
    
    
    func playRound() -> Void {
        assert(!isGameOver())

        
        
        var playerOnesCard : Int? = self.playerOneDeckArray.removeFirst()
        var playerTwosCard : Int? = self.playerTwoDeckArray.removeFirst()
        
        
        playersPot.append(playerOnesCard!)
        playersPot.append(playerTwosCard!)
        
        if (getValue(card: playerOnesCard!) > getValue(card: playerTwosCard!))
        {
            self.playerOneDeckArray.append(contentsOf: playersPot)
            playersPot = []
            isWar = false
            shuffle(player: 1, deckArray: self.playerOneDeckArray)
            shuffle(player: 2, deckArray: self.playerTwoDeckArray)
            return
        }
        else if (getValue(card: playerTwosCard!) > getValue(card: playerOnesCard!))
        {
            self.playerTwoDeckArray.append(contentsOf: playersPot)
            playersPot = []
            isWar = false
            shuffle(player: 1, deckArray: self.playerOneDeckArray)
            shuffle(player: 2, deckArray: self.playerTwoDeckArray)
            return
        }
        
        isWar = true
        
        
            playersPot.append(self.playerOneDeckArray.removeFirst())  // HIGH STAKES WAR : 4 CARDS FORFEITED
            playersPot.append(self.playerTwoDeckArray.removeFirst())
            playersPot.append(self.playerOneDeckArray.removeFirst())
            playersPot.append(self.playerTwoDeckArray.removeFirst())
        
        
        
        
        
        
        
    }
    
    func shuffle(player : Int, deckArray : [Int]) -> Void {
        assert(player == 1 || player == 2)
        assert(deckArray.count > 0)
        
        let shuffledDeck = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: deckArray) as? [Int]
        
        
        if player == 1 {
            self.playerOneDeckArray = shuffledDeck!
        }
        else
        {
            self.playerTwoDeckArray = shuffledDeck!
        }
    }
    
    func isGameOver() -> Bool {
        
        
        if self.playerOneDeckArray.count==0 || self.playerTwoDeckArray.count==0{
            return true
        }
        else
        {
            return false
        }
    
    }
    
    func getWinner() -> Int? {
        assert(isGameOver())
        
        if self.playerOneDeckArray.count == 0 {
            return 2
        }
        else if self.playerTwoDeckArray.count == 0
        {
            return 1
        }
        else
        {
            return nil
        }
        
    }
    
    
    
    
    
    /*func tooManyOf(cardDeck : [Int], element : Int) -> Bool {
        
        var mutantCardDeck = cardDeck
        var howMany : Int = 0
        
        while cardDeck.isEmpty == false {
            if(mutantCardDeck.removeFirst() == element)
            {
                howMany = howMany + 1
            }
        }
        let tooMany = Bool ((howMany > 4))
        
        return tooMany
        
    }
 */
    
    func getValue(card : Int) -> Int {
        assert(card >= 1 && card <= 52)
        
        if(twosCardArray.contains(card))
        {
            return 2
        }
        else if(threesCardArray.contains(card))
        {
            return 3
        }
        else if(foursCardArray.contains(card))
        {
            return 4
        }
        else if(fivesCardArray.contains(card))
        {
            return 5
        }
        else if(sixsCardArray.contains(card))
        {
            return 6
        }
        else if(sevensCardArray.contains(card))
        {
            return 7
        }
        else if(eightsCardArray.contains(card))
        {
            return 8
        }
        else if(ninesCardArray.contains(card))
        {
            return 9
        }
        else if(tensCardArray.contains(card))
        {
            return 10
        }
        else if(jacksCardArray.contains(card))
        {
            return 11
        }
        else if(queensCardArray.contains(card))
        {
            return 12
        }
        else if(kingsCardArray.contains(card))
        {
            return 13
        }
        else
        {
            return 14
        }
        
    }
    
    func getSuit(card : Int) -> String {
        assert(card >= 1 && card <= 52)
        
        if(spadesCardArray.contains(card))
        {
            return "spades"
        }
        else if(diamondsCardArray.contains(card))
        {
            return "diamonds"
        }
        else if(heartsCardArray.contains(card))
        {
            return "hearts"
        }
        else
        {
            return "clubs"
        }
    }
        
    func getCardImage(card : Int) -> UIImage?
    {
        
        if  (getValue(card: card) == 2 && getSuit(card: card) == "spades")
        {
            return #imageLiteral(resourceName: "2_of_spades")
        }
        else if (getValue(card: card) == 2 && getSuit(card: card) == "hearts")
        {
            return #imageLiteral(resourceName: "2_of_hearts")
        }
        else if (getValue(card: card) == 2 && getSuit(card: card) == "clubs")
        {
            return #imageLiteral(resourceName: "2_of_clubs")
        }
        else if (getValue(card: card) == 2 && getSuit(card: card) == "diamonds")
        {
            return #imageLiteral(resourceName: "2_of_diamonds")
        }
        else if (getValue(card: card) == 3 && getSuit(card: card) == "spades")
        {
            return #imageLiteral(resourceName: "3_of_spades")
        }
        else if (getValue(card: card) == 3 && getSuit(card: card) == "hearts")
        {
            return #imageLiteral(resourceName: "3_of_hearts")
        }
        else if (getValue(card: card) == 3 && getSuit(card: card) == "clubs")
        {
            return #imageLiteral(resourceName: "3_of_clubs")
        }
        else if (getValue(card: card) == 3 && getSuit(card: card) == "diamonds")
        {
            return #imageLiteral(resourceName: "3_of_diamonds")
        }
        else if (getValue(card: card) == 4 && getSuit(card: card) == "spades")
        {
            return #imageLiteral(resourceName: "4_of_spades")
        }
        else if (getValue(card: card) == 4 && getSuit(card: card) == "hearts")
        {
            return #imageLiteral(resourceName: "4_of_hearts")
        }
        else if (getValue(card: card) == 4 && getSuit(card: card) == "clubs")
        {
            return #imageLiteral(resourceName: "4_of_clubs")
        }
        else if (getValue(card: card) == 4 && getSuit(card: card) == "diamonds")
        {
            return #imageLiteral(resourceName: "4_of_diamonds")
        }
        else if (getValue(card: card) == 5 && getSuit(card: card) == "spades")
        {
            return #imageLiteral(resourceName: "5_of_spades")
        }
        else if (getValue(card: card) == 5 && getSuit(card: card) == "hearts")
        {
            return #imageLiteral(resourceName: "5_of_hearts")
        }
        else if (getValue(card: card) == 5 && getSuit(card: card) == "clubs")
        {
            return #imageLiteral(resourceName: "5_of_clubs")
        }
        else if (getValue(card: card) == 5 && getSuit(card: card) == "diamonds")
        {
            return #imageLiteral(resourceName: "5_of_diamonds")
        }
        else if (getValue(card: card) == 6 && getSuit(card: card) == "spades")
        {
            return #imageLiteral(resourceName: "6_of_spades")
        }
        else if (getValue(card: card) == 6 && getSuit(card: card) == "hearts")
        {
            return #imageLiteral(resourceName: "6_of_hearts")
        }
        else if (getValue(card: card) == 6 && getSuit(card: card) == "clubs")
        {
            return #imageLiteral(resourceName: "6_of_clubs")
        }
        else if (getValue(card: card) == 6 && getSuit(card: card) == "diamonds")
        {
            return #imageLiteral(resourceName: "6_of_diamonds")
        }
        else if (getValue(card: card) == 7 && getSuit(card: card) == "spades")
        {
            return #imageLiteral(resourceName: "7_of_spades")
        }
        else if (getValue(card: card) == 7 && getSuit(card: card) == "hearts")
        {
            return #imageLiteral(resourceName: "7_of_hearts")
        }
        else if (getValue(card: card) == 7 && getSuit(card: card) == "clubs")
        {
            return #imageLiteral(resourceName: "7_of_clubs")
        }
        else if (getValue(card: card) == 7 && getSuit(card: card) == "diamonds")
        {
            return #imageLiteral(resourceName: "7_of_diamonds")
        }
        else if (getValue(card: card) == 8 && getSuit(card: card) == "spades")
        {
            return #imageLiteral(resourceName: "8_of_spades")
        }
        else if (getValue(card: card) == 8 && getSuit(card: card) == "hearts")
        {
            return #imageLiteral(resourceName: "8_of_hearts")
        }
        else if (getValue(card: card) == 8 && getSuit(card: card) == "clubs")
        {
            return #imageLiteral(resourceName: "8_of_clubs")
        }
        else if (getValue(card: card) == 8 && getSuit(card: card) == "diamonds")
        {
            return #imageLiteral(resourceName: "8_of_diamonds")
        }
        else if (getValue(card: card) == 9 && getSuit(card: card) == "spades")
        {
            return #imageLiteral(resourceName: "9_of_spades")
        }
        else if (getValue(card: card) == 9 && getSuit(card: card) == "hearts")
        {
            return #imageLiteral(resourceName: "9_of_hearts")
        }
        else if (getValue(card: card) == 9 && getSuit(card: card) == "clubs")
        {
            return #imageLiteral(resourceName: "9_of_clubs")
        }
        else if (getValue(card: card) == 9 && getSuit(card: card) == "diamonds")
        {
            return #imageLiteral(resourceName: "9_of_diamonds")
        }
        else if (getValue(card: card) == 10 && getSuit(card: card) == "spades")
        {
            return #imageLiteral(resourceName: "10_of_spades")
        }
        else if (getValue(card: card) == 10 && getSuit(card: card) == "hearts")
        {
            return #imageLiteral(resourceName: "10_of_hearts")
        }
        else if (getValue(card: card) == 10 && getSuit(card: card) == "clubs")
        {
            return #imageLiteral(resourceName: "10_of_clubs")
        }
        else if (getValue(card: card) == 10 && getSuit(card: card) == "diamonds")
        {
            return #imageLiteral(resourceName: "10_of_diamonds")
        }
        else if (getValue(card: card) == 11 && getSuit(card: card) == "spades")
        {
            return #imageLiteral(resourceName: "jack_of_spades")
        }
        else if (getValue(card: card) == 11 && getSuit(card: card) == "hearts")
        {
            return #imageLiteral(resourceName: "jack_of_hearts")
        }
        else if (getValue(card: card) == 11 && getSuit(card: card) == "clubs")
        {
            return #imageLiteral(resourceName: "jack_of_clubs")
        }
        else if (getValue(card: card) == 11 && getSuit(card: card) == "diamonds")
        {
            return #imageLiteral(resourceName: "jack_of_diamonds")
        }
        else if (getValue(card: card) == 12 && getSuit(card: card) == "spades")
        {
            return #imageLiteral(resourceName: "queen_of_spades")
        }
        else if (getValue(card: card) == 12 && getSuit(card: card) == "hearts")
        {
            return #imageLiteral(resourceName: "queen_of_hearts")
        }
        else if (getValue(card: card) == 12 && getSuit(card: card) == "clubs")
        {
            return #imageLiteral(resourceName: "queen_of_clubs")
        }
        else if (getValue(card: card) == 12 && getSuit(card: card) == "diamonds")
        {
            return #imageLiteral(resourceName: "queen_of_diamonds")
        }
        else if (getValue(card: card) == 13 && getSuit(card: card) == "spades")
        {
            return #imageLiteral(resourceName: "king_of_spades")
        }
        else if (getValue(card: card) == 13 && getSuit(card: card) == "hearts")
        {
            return #imageLiteral(resourceName: "king_of_hearts")
        }
        else if (getValue(card: card) == 13 && getSuit(card: card) == "clubs")
        {
            return #imageLiteral(resourceName: "king_of_clubs")
        }
        else if (getValue(card: card) == 13 && getSuit(card: card) == "diamonds")
        {
            return #imageLiteral(resourceName: "king_of_diamonds")
        }
        else if (getValue(card: card) == 14 && getSuit(card: card) == "spades")
        {
            return #imageLiteral(resourceName: "ace_of_spades")
        }
        else if (getValue(card: card) == 14 && getSuit(card: card) == "clubs")
        {
            return #imageLiteral(resourceName: "ace_of_clubs")
        }
        else if (getValue(card: card) == 14 && getSuit(card: card) == "hearts")
        {
            return #imageLiteral(resourceName: "ace_of_hearts")
        }
        else if (getValue(card: card) == 14 && getSuit(card: card) == "diamonds")
        {
            return #imageLiteral(resourceName: "ace_of_diamonds")
        }
        else
        {
            return nil
        }
    }
        
}
        
        
  

    
    
    

    
    

