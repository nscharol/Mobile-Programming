//
//  playScreenViewController.swift
//  War
//
//  Created by COSC2125 on 2/13/18.
//  Copyright © 2018 COSC2125. All rights reserved.
//

import UIKit

var blueCardShownGS : Bool = false
var redCardShownGS : Bool = false
var bothCardsShownGS : Bool = false

var playerOneCardCount : String? = nil
var playerTwoCardCount : String? = nil
import AVFoundation

var winner : Int? = nil



class playScreenViewController: UIViewController {
    
    
    
    var warGame : WarDeck = WarDeck.init()
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        refreshCountLbls()
        playWarSound()
        
        
        
        
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBOutlet weak var imgBluesTableCard: UIImageView!
    @IBOutlet weak var imgRedsTableCard: UIImageView!
    
    @IBOutlet weak var lblPlayerOneCount: UILabel!
    @IBOutlet weak var lblPlayerTwoCount: UILabel!
    
    @IBAction func dealButton(_ sender: UIButton) {
        
        let warAlert = UIAlertController(title : "ALERT!", message: "You are at war!", preferredStyle: .alert)
        warAlert.addAction(UIAlertAction(title: "Bring it on!", style: .default, handler: nil))
        
        if bothCardsShownGS {
            
            
            
            warGame.playRound()
            if(isWar! == true)
            {
                self.present(warAlert, animated: false, completion: nil)
                playWarSound()
            }
            imgRedsTableCard.image = nil
            imgBluesTableCard.image = nil
            redCardShownGS = false
            blueCardShownGS = false
            bothCardsShownGS = false
            
            refreshCountLbls()
            
            if(warGame.isGameOver())
            {
                winner = warGame.getWinner()
                
                let gotoWinScreen = self.storyboard!.instantiateViewController(withIdentifier: "WinScreen") as! winScreenViewController
                self.present(gotoWinScreen, animated: true, completion: nil)
            }
            
            
            
        }
        
        
        
        
        
    }
    
    
    @IBAction func btnBluePlayers(_ sender: UIButton) {
        if !blueCardShownGS {
            imgBluesTableCard.image = warGame.getCardImage(card: warGame.getTopCard(player: 1))
            blueCardShownGS = true
            if redCardShownGS
            {
                bothCardsShownGS = true
            }
            
        }
    }
    
    @IBAction func btnRedPlayers(_ sender: UIButton) {
        if !redCardShownGS {
            imgRedsTableCard.image = warGame.getCardImage(card: warGame.getTopCard(player: 2))
            redCardShownGS = true
            if blueCardShownGS
            {
                bothCardsShownGS = true
            }
        }
    }
    
    func refreshCountLbls() -> Void {
        playerOneCardCount = warGame.playerOneDeckArray.count.description
        playerTwoCardCount = warGame.playerTwoDeckArray.count.description
        lblPlayerOneCount.text = "Count : " + playerOneCardCount!
        lblPlayerTwoCount.text = "Count : " + playerTwoCardCount!
    }
    
    
    var player: AVAudioPlayer?
    
    func playWarSound() {
        guard let url = Bundle.main.url(forResource: "Sword.mp3", withExtension: "mp3") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            try AVAudioSession.sharedInstance().setActive(true)
            
            
            
            /* The following line is required for the player to work on iOS 11. Change the file type accordingly*/
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
            
            /* iOS 10 and earlier require the following line:
             player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileTypeMPEGLayer3) */
            
            guard let player = player else { return }
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    
    
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
